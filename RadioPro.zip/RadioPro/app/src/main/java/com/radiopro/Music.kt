package com.radiopro

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

data class Song(val id: Long, val title: String, val artist: String, val album: String, val durationMs: Long, val uri: Uri)

/** Reads the songs stored on the phone. Works with no internet. */
object MusicStore {
    fun load(ctx: Context): List<Song> {
        val out = ArrayList<Song>()
        val proj = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION,
        )
        val sel = MediaStore.Audio.Media.IS_MUSIC + " != 0 AND " + MediaStore.Audio.Media.DURATION + " >= 30000"
        try {
            ctx.contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, sel, null, MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val iT = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val iA = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val iAl = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val iD = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                while (c.moveToNext()) {
                    val id = c.getLong(iId)
                    val artist = (c.getString(iA) ?: "").let { if (it == "<unknown>") "" else it }
                    out.add(
                        Song(
                            id, (c.getString(iT) ?: "Unknown").trim().ifEmpty { "Unknown" }, artist.trim(), (c.getString(iAl) ?: "").trim(),
                            c.getLong(iD), ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id),
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // no permission or no media: return what we have
        }
        return out
    }
}
