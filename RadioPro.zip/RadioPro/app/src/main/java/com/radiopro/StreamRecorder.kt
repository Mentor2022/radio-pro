package com.radiopro

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Saves what a live internet station is playing right now to the phone (Music > RadioPro).
 * It copies the station's own audio stream, so no re-encoding and little battery use.
 * Streams that are playlists (HLS, .m3u8) cannot be saved this way.
 */
object StreamRecorder {
    private const val MAX_SECONDS = 3 * 60 * 60
    private const val MAX_BYTES = 400L * 1024 * 1024

    /** Returns a short description of where the file went. Throws with a readable message on failure. */
    fun record(ctx: Context, station: Station, shouldStop: () -> Boolean, onTick: (Int) -> Unit): String {
        val conn = URL(station.streamUrl).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 15000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", "RadioPro/1.0")
        val type = (conn.contentType ?: "").lowercase()
        if (conn.responseCode !in 200..299) throw IllegalStateException("The station did not answer (code ${conn.responseCode}).")
        if (type.contains("mpegurl") || type.contains("scpls") || station.streamUrl.lowercase().contains(".m3u8"))
            throw IllegalStateException("This station uses a playlist stream, which cannot be recorded. Try another station.")
        val ext = when {
            type.contains("aac") -> "aac"
            type.contains("ogg") || type.contains("opus") -> "ogg"
            else -> "mp3"
        }
        val mime = when (ext) { "aac" -> "audio/aac"; "ogg" -> "audio/ogg"; else -> "audio/mpeg" }
        val safeName = station.name.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').take(30).ifEmpty { "Radio" }
        val fileName = safeName + "_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + "." + ext

        val tmp = File(ctx.cacheDir, "rec_" + System.currentTimeMillis() + "." + ext)
        var bytes = 0L
        val startedAt = System.currentTimeMillis()
        try {
            conn.inputStream.use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(16 * 1024)
                    var lastTick = 0
                    while (!shouldStop()) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        bytes += n
                        val sec = ((System.currentTimeMillis() - startedAt) / 1000).toInt()
                        if (sec != lastTick) { lastTick = sec; onTick(sec) }
                        if (sec >= MAX_SECONDS || bytes >= MAX_BYTES) break
                    }
                }
            }
        } catch (e: Exception) {
            // A dropped connection ends the recording; keep what we already have
            if (bytes < 50_000) { tmp.delete(); throw IllegalStateException("The recording could not start: " + (e.message ?: "connection problem")) }
        } finally {
            try { conn.disconnect() } catch (e: Exception) { /* ignore */ }
        }
        if (bytes < 50_000) { tmp.delete(); throw IllegalStateException("Nothing was recorded. Try again.") }

        return if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Audio.Media.MIME_TYPE, mime)
                put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/RadioPro")
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val r = ctx.contentResolver
            val uri = r.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values) ?: throw IllegalStateException("Could not save the recording.")
            r.openOutputStream(uri)?.use { out -> tmp.inputStream().use { it.copyTo(out) } }
            values.clear()
            values.put(MediaStore.Audio.Media.IS_PENDING, 0)
            r.update(uri, values, null, null)
            tmp.delete()
            "Music/RadioPro/$fileName"
        } else {
            val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: ctx.filesDir
            val dest = File(dir, fileName)
            tmp.copyTo(dest, true)
            tmp.delete()
            dest.absolutePath
        }
    }
}
