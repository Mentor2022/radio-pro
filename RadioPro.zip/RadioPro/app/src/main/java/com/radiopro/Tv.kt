package com.radiopro

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class TvChannel(val name: String, val url: String, val group: String = "", val logo: String = "")

/** Live TV channels come from a public playlist (M3U) that is saved on the phone, so the list works offline. */
object TvStore {
    private fun file(ctx: Context, cc: String) = File(ctx.filesDir, "tv_" + cc.lowercase().filter { it.isLetter() }.take(2) + ".m3u")

    private val groupRe = Regex("""group-title="([^"]*)"""")
    private val logoRe = Regex("""tvg-logo="([^"]*)"""")

    fun parse(text: String): List<TvChannel> {
        val out = ArrayList<TvChannel>()
        val seen = HashSet<String>()
        var name = ""; var group = ""; var logo = ""
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.startsWith("#EXTINF")) {
                name = line.substringAfterLast(",").trim()
                group = groupRe.find(line)?.groupValues?.get(1)?.trim().orEmpty()
                logo = logoRe.find(line)?.groupValues?.get(1)?.trim().orEmpty()
            } else if (line.isNotEmpty() && !line.startsWith("#") && (line.startsWith("http://") || line.startsWith("https://"))) {
                if (name.isNotBlank() && seen.add(line)) out.add(TvChannel(name.take(60), line, group.take(40), logo))
                name = ""; group = ""; logo = ""
            }
        }
        return out.sortedBy { it.name.lowercase() }
    }

    fun load(ctx: Context, cc: String): List<TvChannel> {
        val f = file(ctx, cc)
        return try { if (f.exists()) parse(f.readText()) else emptyList() } catch (e: Exception) { emptyList() }
    }

    /** Downloads the playlist for a country and keeps it on the phone. Returns how many channels it holds. */
    fun download(ctx: Context, cc: String): Int {
        val url = AppConfig.tvPlaylist.replace("{cc}", cc.lowercase().filter { it.isLetter() }.take(2))
        val con = URL(url).openConnection() as HttpURLConnection
        con.connectTimeout = 15000
        con.readTimeout = 30000
        con.setRequestProperty("User-Agent", "RadioPro/1.0")
        if (con.responseCode !in 200..299) throw IllegalStateException("No channel list found for \"$cc\" (code ${con.responseCode}).")
        val text = con.inputStream.use { it.readBytes() }.let { String(it.copyOf(minOf(it.size, 6_000_000)), Charsets.UTF_8) }
        val list = parse(text)
        if (list.isEmpty()) throw IllegalStateException("The channel list for \"$cc\" is empty.")
        val tmp = File(ctx.filesDir, "tv.tmp")
        tmp.writeText(text)
        tmp.renameTo(file(ctx, cc))
        return list.size
    }
}
