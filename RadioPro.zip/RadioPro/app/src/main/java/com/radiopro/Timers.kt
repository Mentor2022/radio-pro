package com.radiopro

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** An alarm (wake up to a station) or a scheduled recording (save a show at a set time). */
data class RadioTimer(
    val id: Int,
    val kind: String, // "alarm" or "record"
    val hour: Int,
    val minute: Int,
    val days: Int, // bit 1 = Monday ... bit 64 = Sunday; 0 = once
    val enabled: Boolean,
    val label: String,
    val srcName: String, // station name ("" = the phone's alarm sound)
    val srcUrl: String,
    val minutes: Int, // recording length
) {
    val timeLabel: String get() = "%02d:%02d".format(hour, minute)
    val daysLabel: String
        get() = if (days == 0) "Once" else if (days == 127) "Every day" else
            listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun").filterIndexed { i, _ -> days and (1 shl i) != 0 }.joinToString(" ")
}

object TimerStore {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("radio_timers", Context.MODE_PRIVATE)

    fun all(ctx: Context): List<RadioTimer> {
        val out = ArrayList<RadioTimer>()
        try {
            val a = JSONArray(prefs(ctx).getString("list", "[]"))
            for (i in 0 until a.length()) {
                val j = a.getJSONObject(i)
                out.add(
                    RadioTimer(
                        j.getInt("id"), j.getString("kind"), j.getInt("h"), j.getInt("m"), j.getInt("days"), j.getBoolean("on"),
                        j.optString("label"), j.optString("sname"), j.optString("surl"), j.optInt("min", 30),
                    )
                )
            }
        } catch (e: Exception) { /* start empty */ }
        return out
    }

    fun saveAll(ctx: Context, list: List<RadioTimer>) {
        val a = JSONArray()
        for (t in list) {
            a.put(JSONObject().put("id", t.id).put("kind", t.kind).put("h", t.hour).put("m", t.minute).put("days", t.days).put("on", t.enabled)
                .put("label", t.label).put("sname", t.srcName).put("surl", t.srcUrl).put("min", t.minutes))
        }
        prefs(ctx).edit().putString("list", a.toString()).apply()
    }

    fun get(ctx: Context, id: Int): RadioTimer? = all(ctx).firstOrNull { it.id == id }
    fun nextId(ctx: Context): Int = (all(ctx).maxOfOrNull { it.id } ?: 0) + 1

    fun upsert(ctx: Context, t: RadioTimer) {
        saveAll(ctx, all(ctx).filter { it.id != t.id } + t)
        TimerScheduler.schedule(ctx, t)
    }

    fun remove(ctx: Context, id: Int) {
        TimerScheduler.cancel(ctx, id)
        saveAll(ctx, all(ctx).filter { it.id != id })
    }
}

object TimerScheduler {
    private fun fire(ctx: Context, id: Int, snooze: Boolean): PendingIntent {
        val i = Intent(ctx, TimerReceiver::class.java).putExtra("id", id).putExtra("snooze", snooze)
        return PendingIntent.getBroadcast(ctx, if (snooze) id + 100000 else id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun show(ctx: Context): PendingIntent =
        PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun nextTrigger(t: RadioTimer, now: Long = System.currentTimeMillis()): Long {
        for (offset in 0..7) {
            val c = Calendar.getInstance()
            c.timeInMillis = now
            c.add(Calendar.DAY_OF_YEAR, offset)
            c.set(Calendar.HOUR_OF_DAY, t.hour); c.set(Calendar.MINUTE, t.minute); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
            if (c.timeInMillis <= now) continue
            val bit = 1 shl ((c.get(Calendar.DAY_OF_WEEK) + 5) % 7) // Monday = bit 1
            if (t.days == 0 || (t.days and bit) != 0) return c.timeInMillis
        }
        return now + 24L * 3600_000
    }

    fun schedule(ctx: Context, t: RadioTimer) {
        cancel(ctx, t.id)
        if (!t.enabled) return
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(nextTrigger(t), show(ctx)), fire(ctx, t.id, false))
        } catch (e: Exception) { /* alarms not allowed on this phone */ }
    }

    fun snooze(ctx: Context, id: Int, minutes: Int) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(System.currentTimeMillis() + minutes * 60_000L, show(ctx)), fire(ctx, id, true))
        } catch (e: Exception) { /* ignore */ }
    }

    fun cancel(ctx: Context, id: Int) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(fire(ctx, id, false))
        am.cancel(fire(ctx, id, true))
    }

    fun rescheduleAll(ctx: Context) { TimerStore.all(ctx).forEach { schedule(ctx, it) } }
}

class TimerReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) { TimerScheduler.rescheduleAll(ctx); return }
        val id = intent.getIntExtra("id", -1)
        val snooze = intent.getBooleanExtra("snooze", false)
        val t = TimerStore.get(ctx, id) ?: return
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, TimerService::class.java).putExtra("id", id))
        } catch (e: Exception) { /* the phone did not allow it */ }
        if (!snooze) {
            if (t.days == 0) TimerStore.upsert(ctx, t.copy(enabled = false)) // one-time alarms switch themselves off
            else TimerScheduler.schedule(ctx, t)
        }
    }
}

/** Runs the alarm sound or the scheduled recording, with a notification that has Stop (and Snooze for alarms). */
class TimerService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var player: ExoPlayer? = null
    private var ringtone: Ringtone? = null
    private var wake: PowerManager.WakeLock? = null
    @Volatile private var stopRecording = false
    private var timerId = -1

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == "STOP") { finish(); return START_NOT_STICKY }
        if (action == "SNOOZE") { TimerScheduler.snooze(this, intent?.getIntExtra("id", -1) ?: -1, 10); finish(); return START_NOT_STICKY }
        val id = intent?.getIntExtra("id", -1) ?: -1
        val t = TimerStore.get(this, id)
        if (t == null) { stopSelf(); return START_NOT_STICKY }
        timerId = id
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("timers", "Alarms and recordings", NotificationManager.IMPORTANCE_HIGH))
        val n = notification(t, if (t.kind == "alarm") "Alarm" else "Recording ${t.srcName}...")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                100 + id, n,
                if (t.kind == "alarm") ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
            )
        } else startForeground(100 + id, n)
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "radiopro:timer").also { it.acquire((t.minutes.coerceAtLeast(30) + 5) * 60_000L) }
        if (t.kind == "alarm") startAlarm(t) else startRecording(t)
        return START_NOT_STICKY
    }

    private fun notification(t: RadioTimer, text: String): Notification {
        fun svc(action: String, code: Int): PendingIntent =
            PendingIntent.getService(this, code, Intent(this, TimerService::class.java).setAction(action).putExtra("id", t.id), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = NotificationCompat.Builder(this, "timers")
            .setSmallIcon(if (t.kind == "alarm") android.R.drawable.ic_lock_idle_alarm else android.R.drawable.ic_btn_speak_now)
            .setContentTitle(t.label.ifBlank { if (t.kind == "alarm") "Alarm" else "Scheduled recording" })
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setCategory(if (t.kind == "alarm") NotificationCompat.CATEGORY_ALARM else NotificationCompat.CATEGORY_PROGRESS)
            .addAction(0, "Stop", svc("STOP", 1))
        if (t.kind == "alarm") b.addAction(0, "Snooze 10 min", svc("SNOOZE", 2))
        return b.build()
    }

    private fun startAlarm(t: RadioTimer) {
        if (t.srcUrl.isBlank()) { ring(); } else {
            val http = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true).setUserAgent("RadioPro/1.0")
            val p = ExoPlayer.Builder(this)
                .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http)))
                .setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_ALARM).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), false)
                .build()
            p.addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) { ring() }
            })
            p.volume = 1f
            p.setMediaItem(MediaItem.fromUri(t.srcUrl))
            p.prepare()
            p.playWhenReady = true
            player = p
            // no internet or a dead station: fall back to the phone's alarm sound
            handler.postDelayed({ if (player?.isPlaying != true) ring() }, 25_000)
        }
        handler.postDelayed({ finish() }, 30 * 60_000L) // never ring longer than 30 minutes
    }

    private fun ring() {
        if (ringtone != null) return
        try {
            player?.release(); player = null
            val r = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
            if (Build.VERSION.SDK_INT >= 28) r.isLooping = true
            r.audioAttributes = android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_ALARM).build()
            r.play()
            ringtone = r
        } catch (e: Exception) { /* nothing more we can do */ }
    }

    private fun startRecording(t: RadioTimer) {
        val started = System.currentTimeMillis()
        val station = Station(id = "timer" + t.id, name = t.srcName.ifBlank { "Radio" }, streamUrl = t.srcUrl)
        Thread {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val text = try {
                "Saved: " + StreamRecorder.record(this, station, { stopRecording || System.currentTimeMillis() - started >= t.minutes * 60_000L }) { }
            } catch (e: Exception) {
                e.message ?: "The scheduled recording failed."
            }
            handler.post {
                finish()
                val n = NotificationCompat.Builder(this, "timers").setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .setContentTitle(t.label.ifBlank { "Scheduled recording" }).setContentText(text).setAutoCancel(true).build()
                nm.notify(500 + t.id, n)
            }
        }.start()
    }

    private fun finish() {
        stopRecording = true
        handler.removeCallbacksAndMessages(null)
        try { player?.release() } catch (e: Exception) { /* ignore */ }
        player = null
        try { ringtone?.stop() } catch (e: Exception) { /* ignore */ }
        ringtone = null
        try { wake?.takeIf { it.isHeld }?.release() } catch (e: Exception) { /* ignore */ }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopRecording = true
        try { player?.release(); ringtone?.stop() } catch (e: Exception) { /* ignore */ }
        super.onDestroy()
    }
}
