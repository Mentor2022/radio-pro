package com.radiopro

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val swatches = listOf(
    Color(0xFF7C3AED), Color(0xFFEC4899), Color(0xFFF59E0B), Color(0xFF10B981),
    Color(0xFF3B82F6), Color(0xFFEF4444), Color(0xFF06B6D4), Color(0xFFA855F7),
)

private fun swatch(s: Song): Color = swatches[(s.title.hashCode() and 0x7fffffff) % swatches.size]
private fun mmss(ms: Long): String { val t = (ms / 1000).coerceAtLeast(0); return "%d:%02d".format(t / 60, t % 60) }

@Composable
fun MusicScreen(vm: RadioViewModel) {
    val ctx = LocalContext.current
    val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED) }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> granted = ok; if (ok) vm.loadSongs() }
    LaunchedEffect(granted) { if (granted) vm.loadSongs() }
    var q by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize()) {
        NowPlayingCard(vm)

        if (!granted) {
            Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("🎧", fontSize = 56.sp)
                Spacer(Modifier.height(10.dp))
                Text("Play the music on your phone", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Radio Pro needs to see the songs on your phone. They never leave it, and no internet is used.", color = Pal.Muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp))
                Button(onClick = { ask.launch(perm) }) { Text("Allow access to my music") }
            }
            return@Column
        }

        OutlinedTextField(
            q, { q = it }, label = { Text("Search songs or artists") }, singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
        )
        val shown = vm.songs.filter { q.isBlank() || it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true) }
        if (vm.songsLoaded && vm.songs.isEmpty()) {
            Text("No songs found on this phone.", color = Pal.Muted, modifier = Modifier.padding(24.dp))
        } else {
            LazyColumn(Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                itemsIndexed(shown, key = { _, s -> s.id }) { i, s ->
                    val on = vm.musicTrack?.id == s.id
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                            .background(if (on) Pal.Panel2 else Pal.Panel)
                            .clickable { vm.playSongs(shown, i) }.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            Modifier.size(46.dp).clip(CircleShape).background(Brush.linearGradient(listOf(swatch(s), swatch(s).copy(alpha = 0.55f)))),
                            contentAlignment = Alignment.Center,
                        ) { Text(if (on && vm.playing) "🔊" else "🎵", fontSize = 20.sp) }
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(s.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, color = if (on) Pal.Amber else MaterialTheme.colorScheme.onSurface)
                            Text(listOf(s.artist, s.album).filter { it.isNotBlank() }.joinToString(" · ").ifEmpty { "Unknown artist" }, color = Pal.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Text(mmss(s.durationMs), color = Pal.Muted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun NowPlayingCard(vm: RadioViewModel) {
    val t = vm.musicTrack
    val base = if (t != null) swatch(t) else Color(0xFF7C3AED)
    Column(
        Modifier.fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(base, Color(0xFFEC4899), Color(0xFFF59E0B))))
            .padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(96.dp).clip(CircleShape).background(Color(0x33FFFFFF)), contentAlignment = Alignment.Center) { Text("🎵", fontSize = 46.sp) }
        Spacer(Modifier.height(8.dp))
        Text(t?.title ?: "Pick a song", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(t?.let { it.artist.ifEmpty { "Unknown artist" } } ?: "Your music, no internet needed", color = Color(0xFFFFF1F2), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        val dur = vm.musicDur.coerceAtLeast(1L)
        Slider(
            value = vm.musicPos.coerceIn(0L, dur).toFloat(), onValueChange = { vm.musicSeek(it.toLong()) }, valueRange = 0f..dur.toFloat(),
            enabled = t != null,
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color.White, inactiveTrackColor = Color(0x55FFFFFF), disabledThumbColor = Color(0x88FFFFFF), disabledActiveTrackColor = Color(0x55FFFFFF), disabledInactiveTrackColor = Color(0x33FFFFFF)),
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(mmss(vm.musicPos), color = Color.White, fontSize = 11.sp)
            Text(mmss(vm.musicDur), color = Color.White, fontSize = 11.sp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            RoundIcon("🔀", on = vm.shuffleOn) { vm.toggleShuffle() }
            RoundIcon("⏮", on = false) { vm.musicPrev() }
            Box(
                Modifier.size(64.dp).clip(CircleShape).background(Color.White).clickable { vm.togglePlay() },
                contentAlignment = Alignment.Center,
            ) { Text(if (vm.playing) "⏸" else "▶", fontSize = 28.sp, color = Color(0xFF7C3AED)) }
            RoundIcon("⏭", on = false) { vm.musicNext() }
            RoundIcon(if (vm.repeatMode == 2) "🔂" else "🔁", on = vm.repeatMode != 0) { vm.cycleRepeat() }
        }
    }
}

@Composable
private fun RoundIcon(label: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(if (on) Color(0x66FFFFFF) else Color(0x22FFFFFF)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, fontSize = 20.sp, color = Color.White) }
}
