package com.radiopro

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

// ====================== Stations and Favorites ======================

@Composable
fun StationsScreen(vm: RadioViewModel, favOnly: Boolean) {
    val list = remember(vm.all, vm.country, vm.state, vm.query, vm.sortByFreq, vm.favorites, favOnly) { vm.filtered(favOnly) }
    Column(Modifier.fillMaxSize()) {
        if (!favOnly) FilterBar(vm)
        else Text("Your favourite stations", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
        if (list.isEmpty()) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    if (favOnly) "Tap the heart on a station to keep it here."
                    else "No stations here yet. Open More > Download stations to save a list on your phone, or add your own community station.",
                    color = Pal.Muted,
                )
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(list, key = { it.id }) { s -> StationRow(vm, s) }
            }
        }
    }
}

@Composable
fun FilterBar(vm: RadioViewModel) {
    val countries = remember(vm.all) { vm.countries() }
    val states = remember(vm.all, vm.country) { vm.states() }
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Picker(
                countries.firstOrNull { it.first == vm.country }?.second ?: "All countries",
                listOf("" to "All countries") + countries, Modifier.weight(1f),
            ) { vm.chooseCountry(it) }
            Picker(
                vm.state.ifBlank { "All states" },
                listOf("" to "All states") + states.map { it to it }, Modifier.weight(1f),
            ) { vm.chooseState(it) }
        }
        OutlinedTextField(
            value = vm.query, onValueChange = { vm.query = it }, singleLine = true,
            placeholder = { Text("Search name or frequency, e.g. 99.3") }, modifier = Modifier.fillMaxWidth(),
        )
        Row {
            FilterChip(selected = vm.sortByFreq, onClick = { vm.sortByFreq = !vm.sortByFreq }, label = { Text("Sort by frequency") })
        }
    }
}

@Composable
fun Picker(value: String, options: List<Pair<String, String>>, modifier: Modifier, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text(value, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
            Text(" ▾")
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { (k, v) -> DropdownMenuItem(text = { Text(v) }, onClick = { open = false; onPick(k) }) }
        }
    }
}

@Composable
fun StationRow(vm: RadioViewModel, s: Station) {
    val isCurrent = vm.current?.id == s.id
    Card(
        modifier = Modifier.fillMaxWidth().clickable { vm.play(s) },
        colors = CardDefaults.cardColors(containerColor = if (isCurrent) Pal.Panel2 else MaterialTheme.colorScheme.surface),
    ) {
        Row(Modifier.padding(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(s.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val sub = listOf(s.freqLabel, s.state, if (s.bitrate > 0) "${s.bitrate} kbps" else "").filter { it.isNotBlank() }.joinToString(" · ")
                if (sub.isNotEmpty()) Text(sub, color = Pal.Muted, fontSize = 13.sp)
                if (!s.canStream) Text("FM only: use the FM Tuner", color = Pal.Amber, fontSize = 12.sp)
            }
            TextButton(onClick = { vm.toggleFav(s.id) }) {
                Text(if (s.id in vm.favorites) "♥" else "♡", fontSize = 24.sp, color = Pal.Pink)
            }
        }
    }
}

// ====================== Mini player ======================

@Composable
fun MiniPlayer(vm: RadioViewModel) {
    val fm by FmEngine.state.collectAsState()
    val dongleOn = fm.running || fm.connecting
    val s = vm.current
    if (s == null && !dongleOn) return
    Surface(color = Pal.Panel2) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    if (dongleOn) "FM ${fmtMhz(fm.freqMhz)} MHz" else (s?.name ?: ""),
                    fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                val line = if (dongleOn) fm.message.ifBlank { vm.status } else listOf(s?.freqLabel.orEmpty(), vm.status, vm.nowTitle).filter { it.isNotBlank() }.joinToString(" · ")
                Text(line, color = Pal.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (vm.sleepLeftSec > 0) Text("💤 ${vm.sleepLeftSec / 60 + 1}m", fontSize = 12.sp, color = Pal.Muted)
            SignalBars(if (dongleOn) fm.bars else vm.quality)
            Button(onClick = { vm.togglePlay() }) { Text(if (vm.playing || dongleOn) "⏸" else "▶") }
        }
    }
}

@Composable
fun SignalBars(level: Int) {
    Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.padding(horizontal = 10.dp)) {
        for (i in 1..4) {
            Box(
                Modifier.padding(horizontal = 1.dp).width(5.dp).height((6 + i * 5).dp)
                    .background(if (i <= level) Pal.Green else Pal.Muted.copy(alpha = 0.35f))
            )
        }
    }
}

// ====================== FM Tuner (USB dongle) ======================

@Composable
fun TunerScreen(vm: RadioViewModel) {
    val ctx = LocalContext.current
    val fm by FmEngine.state.collectAsState()
    var needDriver by remember { mutableStateOf(false) }
    var gain by remember { mutableStateOf(40.2f) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        // The driver reports back when it is ready; if it is not, the engine says so after a few tries.
        vm.startDongle()
    }

    fun openDriver() {
        val hz = (vm.fmFreq * 1e6).toLong()
        val uri = Uri.parse("iqsrc://-a 127.0.0.1 -p 1234 -f $hz -s ${FmEngine.SAMPLE_RATE}")
        try { launcher.launch(Intent(Intent.ACTION_VIEW, uri)) } catch (e: ActivityNotFoundException) { needDriver = true }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("FM Tuner", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Real FM radio with no internet. Needs an RTL-SDR USB dongle, a USB OTG adapter and the free \"RTL-SDR driver\" app.", color = Pal.Muted, fontSize = 13.sp)

        // the dial
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(fmtMhz(vm.fmFreq), fontSize = 72.sp, fontWeight = FontWeight.Bold, color = Pal.Amber)
            Text("MHz  FM", color = Pal.Muted)
            vm.nameAt(vm.fmFreq)?.let { Text(it, fontWeight = FontWeight.SemiBold) }
        }
        Slider(
            value = vm.fmFreq.toFloat(), valueRange = 87.5f..108f, steps = 204,
            onValueChange = { vm.setFm(((it * 10).roundToInt()) / 10.0) },
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.setFm(((vm.fmFreq - 0.1).coerceAtLeast(87.5) * 10).roundToInt() / 10.0) }, modifier = Modifier.weight(1f)) { Text("−0.1") }
            OutlinedButton(onClick = { vm.setFm(((vm.fmFreq + 0.1).coerceAtMost(108.0) * 10).roundToInt() / 10.0) }, modifier = Modifier.weight(1f)) { Text("+0.1") }
        }

        if (fm.running || fm.connecting) {
            Button(onClick = { vm.stopDongle() }, modifier = Modifier.fillMaxWidth()) { Text("Stop radio") }
        } else {
            Button(onClick = { openDriver() }, modifier = Modifier.fillMaxWidth()) { Text("Start radio") }
        }
        if (fm.message.isNotBlank()) Text(fm.message, color = Pal.Amber)

        if (fm.running) {
            Meter("Signal strength", fm.strengthPct, "${fm.strengthPct}%")
            Meter("Clarity", fm.clarityPct, clarityLabel(fm.clarityPct))
            Text("Gain ${fmtMhz(gain.toDouble())} dB", color = Pal.Muted, fontSize = 13.sp)
            Slider(value = gain, valueRange = 0f..49.6f, onValueChange = { gain = it }, onValueChangeFinished = { FmEngine.setGainDb(gain) })
            Text("If the sound is full of hiss, lower the gain a little. If it is faint, raise it.", color = Pal.Muted, fontSize = 12.sp)

            OutlinedButton(onClick = { FmEngine.scan() }, enabled = !fm.scanning, modifier = Modifier.fillMaxWidth()) {
                Text(if (fm.scanning) "Scanning... ${fm.scanPct}%" else "Scan for stations (about 40 seconds)")
            }
            if (fm.scanning) LinearProgressIndicator(progress = { fm.scanPct / 100f }, modifier = Modifier.fillMaxWidth())
        }

        if (fm.found.isNotEmpty()) {
            Text("Stations found", fontWeight = FontWeight.Bold)
            fm.found.forEach { f ->
                Card(Modifier.fillMaxWidth().clickable { vm.setFm(f.mhz) }) {
                    Row(Modifier.padding(start = 14.dp, top = 6.dp, bottom = 6.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${fmtMhz(f.mhz)} MHz" + (vm.nameAt(f.mhz)?.let { " · $it" } ?: ""), fontWeight = FontWeight.SemiBold)
                            Text("Clarity ${f.clarityPct}%", color = Pal.Muted, fontSize = 12.sp)
                        }
                        TextButton(onClick = {
                            vm.addCommunity("FM ${fmtMhz(f.mhz)} (scanned)", fmtMhz(f.mhz), vm.state, "")
                        }) { Text("Save") }
                    }
                }
            }
        }
    }

    if (needDriver) {
        AlertDialog(
            onDismissRequest = { needDriver = false },
            title = { Text("Install the USB driver") },
            text = { Text("Radio Pro needs the free \"RTL-SDR driver\" app to talk to the dongle. Install it, plug in the dongle, then press Start radio again.") },
            confirmButton = {
                TextButton(onClick = {
                    needDriver = false
                    val id = "marto.rtl_tcp_andro"
                    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$id"))) }
                    catch (e: ActivityNotFoundException) { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$id"))) }
                }) { Text("Open Play Store") }
            },
            dismissButton = { TextButton(onClick = { needDriver = false }) { Text("Not now") } },
        )
    }
}

private fun clarityLabel(p: Int) = when { p >= 70 -> "Clear"; p >= 40 -> "Fair"; p >= 15 -> "Weak"; else -> "No station" }

@Composable
fun Meter(label: String, pct: Int, text: String) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Pal.Muted, fontSize = 13.sp)
            Text(text, fontWeight = FontWeight.SemiBold)
        }
        LinearProgressIndicator(
            progress = { pct.coerceIn(0, 100) / 100f }, color = Pal.Green, trackColor = Pal.Panel2,
            modifier = Modifier.fillMaxWidth().height(8.dp),
        )
    }
}

// ====================== More: download, community, sleep, about ======================

@Composable
fun MoreScreen(vm: RadioViewModel) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        if (vm.message.isNotBlank()) Text(vm.message, color = Pal.Amber)

        if (AppConfig.has("import")) {
            var cc by remember { mutableStateOf(vm.country.ifBlank { AppConfig.defaultCountry }) }
            var st by remember { mutableStateOf(vm.state) }
            Section("Download stations") {
                Text("Saves a station list on your phone so you can browse it with no internet. Needs internet once.", color = Pal.Muted, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("NG", "GH", "KE", "ZA", "GB", "US").forEach { c -> FilterChip(selected = cc == c, onClick = { cc = c }, label = { Text(c) }) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(cc, { cc = it.uppercase().take(2) }, label = { Text("Country code") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(st, { st = it }, label = { Text("State (optional)") }, singleLine = true, modifier = Modifier.weight(1.4f))
                }
                Button(onClick = { vm.importRegion(cc, st) }, modifier = Modifier.fillMaxWidth()) { Text("Download") }
            }
        }

        if (AppConfig.has("community")) {
            var name by remember { mutableStateOf("") }
            var freq by remember { mutableStateOf("") }
            var place by remember { mutableStateOf(vm.state) }
            var url by remember { mutableStateOf("") }
            var err by remember { mutableStateOf("") }
            Section("Add a community station") {
                Text("For a local or campus station that is not in the list. A frequency, a stream address, or both.", color = Pal.Muted, fontSize = 13.sp)
                OutlinedTextField(name, { name = it }, label = { Text("Station name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        freq, { freq = it }, label = { Text("MHz") }, singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    )
                    OutlinedTextField(place, { place = it }, label = { Text("State or community") }, singleLine = true, modifier = Modifier.weight(1.6f))
                }
                OutlinedTextField(url, { url = it }, label = { Text("Stream address (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
                if (err.isNotBlank()) Text(err, color = Pal.Pink)
                Button(onClick = {
                    val e = vm.addCommunity(name, freq, place, url)
                    err = e ?: ""
                    if (e == null) { name = ""; freq = ""; url = "" }
                }, modifier = Modifier.fillMaxWidth()) { Text("Add station") }

                val mine = vm.all.filter { it.source == Source.COMMUNITY }
                mine.forEach { s ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(s.name, fontWeight = FontWeight.SemiBold)
                            Text(listOf(s.freqLabel, s.state).filter { it.isNotBlank() }.joinToString(" · "), color = Pal.Muted, fontSize = 12.sp)
                        }
                        TextButton(onClick = { vm.deleteCommunity(s.id) }) { Text("Delete") }
                    }
                }
            }
        }

        if (AppConfig.has("sleep")) {
            Section("Sleep timer") {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(15, 30, 60, 90).forEach { m -> OutlinedButton(onClick = { vm.setSleep(m) }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("${m}m") } }
                    OutlinedButton(onClick = { vm.setSleep(0) }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("Off") }
                }
                if (vm.sleepLeftSec > 0) Text("Radio stops in ${vm.sleepLeftSec / 60 + 1} minutes", color = Pal.Muted)
            }
        }

        Section("How it works") {
            Text(
                "Internet stations play with the signal quality shown as bars (based on how smoothly the stream is running). " +
                    "The station list, your favourites and community stations work with no internet. " +
                    "The FM Tuner picks up real radio waves through a USB dongle and needs no internet at all.",
                color = Pal.Muted, fontSize = 13.sp,
            )
        }
    }
}

@Composable
fun Section(title: String, content: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(14.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            content()
        }
    }
}
