package com.radiopro

import android.content.Context
import android.content.SharedPreferences

/** Equalizer settings. The playback service reads them and applies them to the sound. */
object EqPrefs {
    const val FILE = "radio_eq"
    val presets: List<Pair<String, FloatArray>> = listOf(
        "Flat" to floatArrayOf(0f, 0f, 0f, 0f, 0f),
        "Bass" to floatArrayOf(6f, 4f, 0f, -1f, -1f),
        "Pop" to floatArrayOf(-1f, 2f, 4f, 2f, -1f),
        "Rock" to floatArrayOf(5f, 2f, -1f, 2f, 5f),
        "Vocal" to floatArrayOf(-2f, 0f, 4f, 3f, 0f),
        "Treble" to floatArrayOf(-2f, -1f, 0f, 4f, 6f),
    )

    fun prefs(ctx: Context): SharedPreferences = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    fun isOn(ctx: Context) = prefs(ctx).getBoolean("on", false)
    fun preset(ctx: Context) = prefs(ctx).getInt("preset", 0).coerceIn(0, presets.lastIndex)
    /** Bass boost strength, 0 to 1000 */
    fun bass(ctx: Context) = prefs(ctx).getInt("bass", 0).coerceIn(0, 1000)
}
