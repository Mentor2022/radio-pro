package com.radiopro

import android.content.SharedPreferences
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Plays radio, music and podcasts in the background with a notification and lock-screen controls.
 * The buffer is small on purpose: a radio stream should start fast and stay close to "live".
 */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private var eq: Equalizer? = null
    private var boost: BassBoost? = null
    private var eqListener: SharedPreferences.OnSharedPreferenceChangeListener? = null

    override fun onCreate() {
        super.onCreate()
        // Many streams redirect from http to https, so cross-protocol redirects are allowed
        val http = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true).setUserAgent("RadioPro/1.0")
        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http)))
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),
                true, // pause for phone calls and other apps
            )
            .setHandleAudioBecomingNoisy(true) // pause when headphones are unplugged
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .setLoadControl(DefaultLoadControl.Builder().setBufferDurationsMs(15_000, 50_000, 1_500, 3_000).build())
            .build()
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) { applyEq(audioSessionId) }
        })
        val l = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> applyEq(player.audioSessionId) }
        eqListener = l
        EqPrefs.prefs(this).registerOnSharedPreferenceChangeListener(l)
        applyEq(player.audioSessionId)
        session = MediaSession.Builder(this, player).build()
    }

    /** Sets the equalizer and bass boost to what the person chose. Silent if the phone does not support it. */
    private fun applyEq(sessionId: Int) {
        if (sessionId == 0) return
        try {
            eq?.release(); boost?.release(); eq = null; boost = null
            val on = EqPrefs.isOn(this)
            val gains = EqPrefs.presets[EqPrefs.preset(this)].second
            val e = Equalizer(0, sessionId)
            val n = e.numberOfBands.toInt()
            val range = e.bandLevelRange
            for (b in 0 until n) {
                val g = gains[Math.round(b * (gains.size - 1) / maxOf(n - 1, 1).toFloat()).coerceIn(0, gains.lastIndex)]
                val level = (g * 100).toInt().coerceIn(range[0].toInt(), range[1].toInt())
                e.setBandLevel(b.toShort(), level.toShort())
            }
            e.enabled = on
            eq = e
            val bs = BassBoost(0, sessionId)
            val strength = EqPrefs.bass(this)
            if (bs.strengthSupported) bs.setStrength(strength.toShort())
            bs.enabled = on && strength > 0
            boost = bs
        } catch (e: Exception) {
            // equalizer not available on this phone
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onDestroy() {
        eqListener?.let { EqPrefs.prefs(this).unregisterOnSharedPreferenceChangeListener(it) }
        try { eq?.release(); boost?.release() } catch (e: Exception) { /* ignore */ }
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }
}
