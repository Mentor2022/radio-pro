package com.radiopro

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Pal {
    val Bg = Color(0xFF08141A)
    val Panel = Color(0xFF10252E)
    val Panel2 = Color(0xFF173642)
    val Teal = Color(0xFF14B8A6)
    val Amber = Color(0xFFFBBF24)
    val Green = Color(0xFF34D399)
    val Pink = Color(0xFFF472B6)
    val Text = Color(0xFFF0FDFA)
    val Muted = Color(0xFF8FB3B0)
}

@Composable
fun RadioProTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Pal.Teal, onPrimary = Color.Black, secondary = Pal.Amber, tertiary = Pal.Pink,
            background = Pal.Bg, surface = Pal.Panel, onBackground = Pal.Text, onSurface = Pal.Text,
            surfaceVariant = Pal.Panel2, onSurfaceVariant = Pal.Muted,
        ),
        content = content,
    )
}
