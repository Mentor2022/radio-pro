@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.radiopro

import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

// ───────────── tabs that group screens ─────────────

@Composable
fun RadioTab(vm: RadioViewModel) {
    var sub by rememberSaveable { mutableStateOf("all") }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = sub == "all", onClick = { sub = "all" }, label = { Text("Stations") })
            FilterChip(selected = sub == "fav", onClick = { sub = "fav" }, label = { Text("♥ Favorites") })
            if (AppConfig.has("dongle")) FilterChip(selected = sub == "fm", onClick = { sub = "fm" }, label = { Text("📡 FM Tuner") })
        }
        Box(Modifier.weight(1f)) {
            when (sub) {
                "fav" -> StationsScreen(vm, favOnly = true)
                "fm" -> TunerScreen(vm)
                else -> StationsScreen(vm, favOnly = false)
            }
        }
    }
}

@Composable
fun AudioTab(vm: RadioViewModel) {
    var sub by rememberSaveable { mutableStateOf("songs") }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = sub == "songs", onClick = { sub = "songs" }, label = { Text("🎵 Songs") })
            if (AppConfig.has("recordings")) FilterChip(selected = sub == "rec", onClick = { sub = "rec" }, label = { Text("⏺ Recordings") })
            if (AppConfig.has("podcasts")) FilterChip(selected = sub == "pod", onClick = { sub = "pod" }, label = { Text("🎙 Podcasts") })
        }
        Box(Modifier.weight(1f)) {
            when (sub) {
                "rec" -> RecordingsScreen(vm)
                "pod" -> PodcastsScreen(vm)
                else -> MusicScreen(vm)
            }
        }
    }
}

// ───────────── recordings ─────────────

@Composable
fun RecordingsScreen(vm: RadioViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf<List<Song>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<Song?>(null) }
    var deleting by remember { mutableStateOf<Song?>(null) }
    var draft by remember { mutableStateOf("") }
    fun reload() { scope.launch { list = withContext(Dispatchers.IO) { RecStore.list(ctx) }; loaded = true } }
    LaunchedEffect(vm.recording) { if (!vm.recording) reload() }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        Text("Radio recordings", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))
        if (loaded && list.isEmpty()) {
            Text("No recordings yet. Play an internet station and tap ⏺ Rec, or set a scheduled recording in the Alarm tab.", color = Pal.Muted)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(list, key = { it.id }) { s ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if (vm.musicTrack?.id == s.id) Pal.Panel2 else Pal.Panel)
                        .clickable { vm.playSongs(list, list.indexOf(s)) }.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("⏺", fontSize = 20.sp, color = Pal.Pink, modifier = Modifier.padding(end = 10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(s.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (s.durationMs > 0) Text(("%d:%02d".format(s.durationMs / 60000, (s.durationMs / 1000) % 60)), color = Pal.Muted, fontSize = 12.sp)
                    }
                    TextButton(onClick = { draft = s.title; renaming = s }) { Text("✏️") }
                    TextButton(onClick = { deleting = s }) { Text("🗑") }
                }
            }
        }
    }
    renaming?.let { s ->
        AlertDialog(
            onDismissRequest = { renaming = null }, title = { Text("Rename recording") },
            text = { OutlinedTextField(draft, { draft = it.take(60) }, singleLine = true) },
            confirmButton = { TextButton(onClick = { RecStore.rename(ctx, s, draft); renaming = null; reload() }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Cancel") } },
        )
    }
    deleting?.let { s ->
        AlertDialog(
            onDismissRequest = { deleting = null }, title = { Text("Delete this recording?") }, text = { Text(s.title) },
            confirmButton = { TextButton(onClick = { RecStore.delete(ctx, s); deleting = null; reload() }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } },
        )
    }
}

// ───────────── podcasts ─────────────

@Composable
fun PodcastsScreen(vm: RadioViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var subs by remember { mutableStateOf(PodApi.subs(ctx)) }
    var q by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Podcast>>(emptyList()) }
    var show by remember { mutableStateOf<Podcast?>(null) }
    var episodes by remember { mutableStateOf<List<Episode>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }

    fun openShow(p: Podcast) {
        show = p; episodes = emptyList(); busy = true; msg = ""
        scope.launch {
            try { episodes = withContext(Dispatchers.IO) { PodApi.episodes(p.feedUrl) } }
            catch (e: Exception) { msg = "Could not load this podcast. Check your internet." }
            busy = false
        }
    }
    fun search() {
        if (q.isBlank()) return
        busy = true; msg = ""
        scope.launch {
            try { results = withContext(Dispatchers.IO) { PodApi.search(q.trim()) }; if (results.isEmpty()) msg = "Nothing found. Try another name." }
            catch (e: Exception) { msg = "Search needs internet." }
            busy = false
        }
    }

    val current = show
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        if (current != null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { show = null }) { Text("← Back") }
                Text(current.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            val isSub = subs.any { it.feedUrl == current.feedUrl }
            Button(onClick = {
                subs = if (isSub) subs.filter { it.feedUrl != current.feedUrl } else subs + current
                PodApi.saveSubs(ctx, subs)
            }) { Text(if (isSub) "✔ Subscribed (tap to remove)" else "＋ Subscribe") }
            if (busy) Text("Loading episodes...", color = Pal.Muted, modifier = Modifier.padding(8.dp))
            if (msg.isNotEmpty()) Text(msg, color = Pal.Amber, modifier = Modifier.padding(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 8.dp)) {
                items(episodes, key = { it.url }) { ep ->
                    val saved = vm.podDownloads.containsKey(ep.url)
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Pal.Panel).padding(10.dp)) {
                        Text(ep.title, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(listOf(ep.date, ep.length).filter { it.isNotBlank() }.joinToString(" · "), color = Pal.Muted, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton(onClick = { vm.playEpisode(ep, current.name) }) { Text("▶ Play") }
                            if (saved) TextButton(onClick = { vm.removeEpisodeDownload(ep) }) { Text("✔ Saved offline · remove") }
                            else TextButton(onClick = { vm.downloadEpisode(ep) }, enabled = vm.podBusy.isEmpty()) { Text(if (vm.podBusy == ep.url) "Downloading..." else "⬇ Download") }
                        }
                    }
                }
            }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
                OutlinedTextField(q, { q = it }, label = { Text("Search podcasts") }, singleLine = true, modifier = Modifier.weight(1f))
                TextButton(onClick = { search() }, enabled = !busy) { Text("Search") }
            }
            if (busy) Text("Please wait...", color = Pal.Muted, modifier = Modifier.padding(8.dp))
            if (msg.isNotEmpty()) Text(msg, color = Pal.Amber, modifier = Modifier.padding(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 8.dp)) {
                if (results.isNotEmpty()) {
                    item { Text("RESULTS", color = Pal.Muted, fontSize = 12.sp) }
                    items(results, key = { "r" + it.feedUrl }) { p -> PodRow(p) { openShow(p) } }
                }
                item { Text("MY PODCASTS", color = Pal.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)) }
                if (subs.isEmpty()) item { Text("Search for a show and tap Subscribe. Downloaded episodes play with no internet.", color = Pal.Muted, fontSize = 13.sp) }
                items(subs, key = { "s" + it.feedUrl }) { p -> PodRow(p) { openShow(p) } }
            }
        }
    }
}

@Composable
private fun PodRow(p: Podcast, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Pal.Panel).clickable(onClick = onClick).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("🎙", fontSize = 22.sp, modifier = Modifier.padding(end = 10.dp))
        Column(Modifier.weight(1f)) {
            Text(p.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (p.artist.isNotBlank()) Text(p.artist, color = Pal.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

// ───────────── alarms and scheduled recordings ─────────────

@Composable
fun TimersScreen(vm: RadioViewModel) {
    val ctx = LocalContext.current
    var list by remember { mutableStateOf(TimerStore.all(ctx)) }
    var creating by remember { mutableStateOf<String?>(null) }
    fun reload() { list = TimerStore.all(ctx) }

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Alarms and recordings", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { creating = "alarm" }) { Text("＋ ⏰ Radio alarm") }
            if (AppConfig.has("recordings")) Button(onClick = { creating = "record" }) { Text("＋ ⏺ Scheduled recording") }
        }
        Text("An alarm wakes you with a station (or your phone's alarm sound if the station is offline). A scheduled recording saves a show at the time you choose. Both need the app allowed to run in the background.", color = Pal.Muted, fontSize = 12.sp)
        if (list.isEmpty()) Text("Nothing set yet.", color = Pal.Muted)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list, key = { it.id }) { t ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Pal.Panel).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text((if (t.kind == "alarm") "⏰ " else "⏺ ") + t.timeLabel, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text(t.daysLabel + (if (t.kind == "record") " · ${t.minutes} min" else ""), color = Pal.Muted, fontSize = 12.sp)
                        Text(t.srcName.ifBlank { "Phone alarm sound" } + (if (t.label.isNotBlank()) " · " + t.label else ""), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Switch(checked = t.enabled, onCheckedChange = { TimerStore.upsert(ctx, t.copy(enabled = it)); reload() })
                    TextButton(onClick = { TimerStore.remove(ctx, t.id); reload() }) { Text("🗑") }
                }
            }
        }
    }
    creating?.let { kind -> TimerDialog(vm, kind, onDone = { creating = null; reload() }) }
}

@Composable
private fun TimerDialog(vm: RadioViewModel, kind: String, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val now = remember { Calendar.getInstance() }
    var hour by remember { mutableStateOf(if (kind == "alarm") 7 else (now.get(Calendar.HOUR_OF_DAY) + 1) % 24) }
    var minute by remember { mutableStateOf(if (kind == "alarm") 0 else 0) }
    var days by remember { mutableStateOf(0) }
    var label by remember { mutableStateOf("") }
    var minutes by remember { mutableStateOf(30) }
    var station by remember { mutableStateOf<Station?>(null) }
    var filter by remember { mutableStateOf("") }
    val choices = remember(vm.all, filter) { vm.all.filter { it.canStream && (filter.isBlank() || it.name.contains(filter, true)) }.take(30) }
    var err by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDone,
        title = { Text(if (kind == "alarm") "New radio alarm" else "New scheduled recording") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { TimePickerDialog(ctx, { _, h, m -> hour = h; minute = m }, hour, minute, true).show() }) { Text("Time: %02d:%02d  (tap to change)".format(hour, minute)) }
                Text("Repeat", color = Pal.Muted, fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("M", "T", "W", "T", "F", "S", "S").forEachIndexed { i, d ->
                        FilterChip(selected = days and (1 shl i) != 0, onClick = { days = days xor (1 shl i) }, label = { Text(d) })
                    }
                }
                Text(if (days == 0) "No days chosen: it happens once." else "", color = Pal.Muted, fontSize = 11.sp)
                if (kind == "record") {
                    Text("Length", color = Pal.Muted, fontSize = 12.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        for (m in listOf(15, 30, 60, 90, 120)) FilterChip(selected = minutes == m, onClick = { minutes = m }, label = { Text("$m min") })
                    }
                }
                OutlinedTextField(label, { label = it.take(30) }, label = { Text("Name (optional)") }, singleLine = true)
                Text(if (kind == "alarm") "Station (optional: empty uses your phone's alarm sound)" else "Station to record", color = Pal.Muted, fontSize = 12.sp)
                station?.let { Text("Chosen: " + it.name, fontWeight = FontWeight.SemiBold, color = Pal.Amber) }
                OutlinedTextField(filter, { filter = it }, label = { Text("Search your stations") }, singleLine = true)
                Column(Modifier.heightIn(max = 160.dp).verticalScroll(rememberScrollState())) {
                    for (s in choices) Text(s.name, modifier = Modifier.fillMaxWidth().clickable { station = s }.padding(vertical = 8.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (choices.isEmpty()) Text("Download stations first (More > Download stations).", color = Pal.Muted, fontSize = 12.sp)
                }
                if (err.isNotEmpty()) Text(err, color = Pal.Amber, fontSize = 12.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (kind == "record" && station == null) {
                    err = "Choose a station to record."
                } else {
                    val t = RadioTimer(TimerStore.nextId(ctx), kind, hour, minute, days, true, label.trim(), station?.name.orEmpty(), station?.streamUrl.orEmpty(), minutes)
                    TimerStore.upsert(ctx, t)
                    onDone()
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDone) { Text("Cancel") } },
    )
}

// ───────────── equalizer ─────────────

@Composable
fun EqualizerSection() {
    val ctx = LocalContext.current
    val prefs = remember { EqPrefs.prefs(ctx) }
    var on by remember { mutableStateOf(EqPrefs.isOn(ctx)) }
    var preset by remember { mutableStateOf(EqPrefs.preset(ctx)) }
    var bass by remember { mutableStateOf(EqPrefs.bass(ctx).toFloat()) }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Pal.Panel).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🎚 Equalizer and bass boost", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Switch(checked = on, onCheckedChange = { on = it; prefs.edit().putBoolean("on", it).apply() })
        }
        Text("Works for radio streams, music and podcasts. It does not change the USB dongle sound.", color = Pal.Muted, fontSize = 12.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            EqPrefs.presets.forEachIndexed { i, p -> FilterChip(selected = preset == i, onClick = { preset = i; prefs.edit().putInt("preset", i).apply() }, label = { Text(p.first) }) }
        }
        Text("Bass boost", color = Pal.Muted, fontSize = 12.sp)
        Slider(value = bass, onValueChange = { bass = it }, onValueChangeFinished = { prefs.edit().putInt("bass", bass.toInt()).apply() }, valueRange = 0f..1000f)
    }
}
