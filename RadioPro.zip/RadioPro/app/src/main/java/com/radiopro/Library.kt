package com.radiopro

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Xml
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** The radio recordings saved by Radio Pro (Music > RadioPro). */
object RecStore {
    fun list(ctx: Context): List<Song> {
        val out = ArrayList<Song>()
        if (Build.VERSION.SDK_INT >= 29) {
            val proj = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.DURATION)
            try {
                ctx.contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj,
                    MediaStore.Audio.Media.RELATIVE_PATH + " LIKE ?", arrayOf(Environment.DIRECTORY_MUSIC + "/RadioPro%"),
                    MediaStore.Audio.Media.DATE_ADDED + " DESC",
                )?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getLong(0)
                        val name = c.getString(1) ?: "Recording"
                        out.add(Song(id, name.substringBeforeLast('.'), "Radio recording", "", c.getLong(2), ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)))
                    }
                }
            } catch (e: Exception) { /* no recordings */ }
        } else {
            val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_MUSIC)
            for (f in (dir?.listFiles() ?: emptyArray()).sortedByDescending { it.lastModified() }) {
                out.add(Song(f.absolutePath.hashCode().toLong(), f.nameWithoutExtension, "Radio recording", "", 0L, Uri.fromFile(f)))
            }
        }
        return out
    }

    fun delete(ctx: Context, s: Song): Boolean = try {
        if (s.uri.scheme == "file") File(s.uri.path ?: "").delete() else ctx.contentResolver.delete(s.uri, null, null) > 0
    } catch (e: Exception) { false }

    fun rename(ctx: Context, s: Song, newName: String): Boolean {
        val clean = newName.replace(Regex("[\\\\/:*?\"<>|]+"), " ").trim().take(60)
        if (clean.isEmpty()) return false
        return try {
            if (s.uri.scheme == "file") {
                val f = File(s.uri.path ?: "")
                f.renameTo(File(f.parentFile, clean + "." + f.extension))
            } else {
                val ext = ctx.contentResolver.query(s.uri, arrayOf(MediaStore.Audio.Media.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) (c.getString(0) ?: "").substringAfterLast('.', "mp3") else "mp3"
                } ?: "mp3"
                val v = ContentValues().apply { put(MediaStore.Audio.Media.DISPLAY_NAME, "$clean.$ext") }
                ctx.contentResolver.update(s.uri, v, null, null) > 0
            }
        } catch (e: Exception) { false }
    }
}

data class Podcast(val name: String, val artist: String, val feedUrl: String)
data class Episode(val title: String, val url: String, val date: String, val length: String)

/** Podcasts come from the free iTunes directory and the show's own RSS feed. Needs internet; downloaded episodes play offline. */
object PodApi {
    private fun open(url: String): HttpURLConnection {
        var u = url
        for (i in 0 until 5) {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 15000; c.readTimeout = 20000; c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", "RadioPro/1.0")
            val code = c.responseCode
            if (code in 300..399) { val loc = c.getHeaderField("Location") ?: break; u = URL(URL(u), loc).toString(); c.disconnect(); continue }
            if (code !in 200..299) throw IllegalStateException("The server answered with code $code.")
            return c
        }
        throw IllegalStateException("Too many redirects.")
    }

    fun search(term: String): List<Podcast> {
        val c = open("https://itunes.apple.com/search?media=podcast&limit=25&term=" + URLEncoder.encode(term, "UTF-8"))
        val text = c.inputStream.use { String(it.readBytes(), Charsets.UTF_8) }
        val arr = JSONObject(text).getJSONArray("results")
        val out = ArrayList<Podcast>()
        for (i in 0 until arr.length()) {
            val j = arr.getJSONObject(i)
            val feed = j.optString("feedUrl")
            if (feed.startsWith("http")) out.add(Podcast(j.optString("collectionName", "Podcast"), j.optString("artistName"), feed))
        }
        return out
    }

    fun episodes(feed: String): List<Episode> {
        val c = open(feed)
        val out = ArrayList<Episode>()
        c.inputStream.use { stream ->
            val p = Xml.newPullParser()
            p.setInput(stream, null)
            var ev = p.eventType
            var inItem = false
            var title = ""; var url = ""; var date = ""; var dur = ""
            while (ev != XmlPullParser.END_DOCUMENT && out.size < 60) {
                if (ev == XmlPullParser.START_TAG) {
                    when (p.name) {
                        "item" -> { inItem = true; title = ""; url = ""; date = ""; dur = "" }
                        "title" -> if (inItem) title = p.nextText()
                        "enclosure" -> if (inItem) url = p.getAttributeValue(null, "url") ?: ""
                        "pubDate" -> if (inItem) date = p.nextText().trim().take(16)
                        "itunes:duration" -> if (inItem) dur = p.nextText().trim()
                    }
                } else if (ev == XmlPullParser.END_TAG && p.name == "item") {
                    inItem = false
                    if (url.startsWith("http")) out.add(Episode(title.trim().ifEmpty { "Episode" }, url, date, dur))
                }
                ev = p.next()
            }
        }
        return out
    }

    // subscriptions
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("radio_podcasts", Context.MODE_PRIVATE)

    fun subs(ctx: Context): List<Podcast> = try {
        val a = JSONArray(prefs(ctx).getString("subs", "[]"))
        (0 until a.length()).map { val j = a.getJSONObject(it); Podcast(j.getString("n"), j.optString("a"), j.getString("f")) }
    } catch (e: Exception) { emptyList() }

    fun saveSubs(ctx: Context, list: List<Podcast>) {
        val a = JSONArray(); list.forEach { a.put(JSONObject().put("n", it.name).put("a", it.artist).put("f", it.feedUrl)) }
        prefs(ctx).edit().putString("subs", a.toString()).apply()
    }

    // downloaded episodes: episode url -> file name inside the app
    fun downloads(ctx: Context): Map<String, String> = try {
        val j = JSONObject(prefs(ctx).getString("dl", "{}"))
        j.keys().asSequence().associateWith { j.getString(it) }
    } catch (e: Exception) { emptyMap() }

    fun saveDownloads(ctx: Context, m: Map<String, String>) {
        val j = JSONObject(); m.forEach { (k, v) -> j.put(k, v) }
        prefs(ctx).edit().putString("dl", j.toString()).apply()
    }

    fun fileFor(ctx: Context, url: String) = File(ctx.filesDir, "pod_" + (url.hashCode().toLong() and 0xffffffffL) + ".mp3")

    /** Downloads one episode to the phone. */
    fun download(ctx: Context, url: String): String {
        val c = open(url)
        val f = fileFor(ctx, url)
        val tmp = File(f.path + ".part")
        c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        tmp.renameTo(f)
        return f.name
    }
}
