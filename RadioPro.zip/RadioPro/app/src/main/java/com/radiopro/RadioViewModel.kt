package com.radiopro

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class RadioViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context get() = getApplication<Application>()
    private val prefs = app.getSharedPreferences("radio", Context.MODE_PRIVATE)

    // ---- what the screens show ----
    var all by mutableStateOf<List<Station>>(emptyList())
        private set
    var favorites by mutableStateOf<Set<String>>(prefs.getStringSet("fav", emptySet())?.toSet() ?: emptySet())
        private set
    var country by mutableStateOf(prefs.getString("country", null) ?: AppConfig.defaultCountry)
        private set
    var state by mutableStateOf(prefs.getString("state", null) ?: AppConfig.defaultState)
        private set
    var query by mutableStateOf("")
    var sortByFreq by mutableStateOf(true)
    var current by mutableStateOf<Station?>(null)
        private set
    var playing by mutableStateOf(false)
        private set
    var status by mutableStateOf("")
        private set
    var nowTitle by mutableStateOf("")
        private set
    /** Stream quality 0 to 4, from how often the stream had to stop and refill in the last minute. */
    var quality by mutableIntStateOf(0)
        private set
    var sleepLeftSec by mutableIntStateOf(0)
        private set
    var message by mutableStateOf("")
        private set
    var fmFreq by mutableDoubleStateOf(prefs.getFloat("fm", 99.3f).toDouble())
        private set

    // ---- internals ----
    private var controller: MediaController? = null
    private var hasError = false
    private var failed = false
    private var retries = 0
    private var lastState = Player.STATE_IDLE
    private val rebuffers = ArrayDeque<Long>()
    private var sleepEnd = 0L
    private var dongleActive = false

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) = refresh()

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_BUFFERING && lastState == Player.STATE_READY) rebuffers.addLast(System.currentTimeMillis())
            if (playbackState == Player.STATE_READY) { hasError = false; failed = false; retries = 0 }
            lastState = playbackState
            refresh()
        }

        override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
            val t = mediaMetadata.title?.toString().orEmpty()
            nowTitle = if (t.isNotBlank() && t != current?.name) t else ""
        }

        override fun onPlayerError(error: PlaybackException) {
            hasError = true
            scheduleRetry()
            refresh()
        }
    }

    init {
        loadStations()
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({
            try {
                controller = future.get().also { it.addListener(listener) }
                refresh()
            } catch (e: Exception) { message = "The radio player could not start" }
        }, ContextCompat.getMainExecutor(ctx))
        viewModelScope.launch { while (true) { delay(1000); tick() } }
        viewModelScope.launch {
            FmEngine.state.collect { s ->
                if (dongleActive && !s.running && !s.connecting) { dongleActive = false; DongleService.stop(ctx) }
                refresh()
            }
        }
    }

    // ---------- stations ----------

    private fun loadStations() {
        viewModelScope.launch(Dispatchers.IO) { all = StationStore.loadAll(ctx) }
    }

    fun countries(): List<Pair<String, String>> =
        all.filter { it.countryCode.isNotBlank() }.map { it.countryCode to it.country.ifBlank { it.countryCode } }
            .distinct().sortedBy { it.second }

    fun states(): List<String> =
        all.filter { country.isBlank() || it.countryCode == country }.map { it.state.trim() }
            .filter { it.isNotEmpty() }.distinct().sortedBy { it.lowercase() }

    fun chooseCountry(c: String) { country = c; state = ""; prefs.edit().putString("country", c).putString("state", "").apply() }
    fun chooseState(s: String) { state = s; prefs.edit().putString("state", s).apply() }

    fun filtered(favOnly: Boolean): List<Station> {
        // a station we only know by frequency is hidden once a downloaded copy with a stream exists
        val withStream = all.filter { it.source == Source.ONLINE && it.freqMhz > 0 }.map { it.countryCode to it.freqMhz }.toHashSet()
        var l = all.filter { !(it.source == Source.BUNDLED && !it.canStream && (it.countryCode to it.freqMhz) in withStream) }
        if (favOnly) {
            l = l.filter { it.id in favorites }
        } else {
            if (country.isNotBlank()) l = l.filter { it.countryCode == country }
            if (state.isNotBlank()) l = l.filter { it.state.equals(state, true) }
            val q = query.trim().lowercase()
            if (q.isNotEmpty()) l = l.filter {
                it.name.lowercase().contains(q) || it.freqLabel.contains(q) || it.state.lowercase().contains(q) || it.tags.lowercase().contains(q)
            }
        }
        return if (sortByFreq) l.sortedWith(compareBy({ if (it.freqMhz > 0) 0 else 1 }, { it.freqMhz }, { it.name.lowercase() }))
        else l.sortedBy { it.name.lowercase() }
    }

    fun nameAt(mhz: Double): String? =
        all.firstOrNull {
            kotlin.math.abs(it.freqMhz - mhz) < 0.05 && (country.isBlank() || it.countryCode == country) &&
                (state.isBlank() || it.state.equals(state, true))
        }?.name

    fun toggleFav(id: String) {
        favorites = if (id in favorites) favorites - id else favorites + id
        prefs.edit().putStringSet("fav", favorites).apply()
    }

    /** Downloads one country (and optionally one state) and keeps it on the phone for offline browsing. */
    fun importRegion(cc: String, st: String) {
        if (cc.trim().length != 2) { message = "Type a two-letter country code, for example NG"; return }
        message = "Downloading stations..."
        viewModelScope.launch {
            try {
                val got = withContext(Dispatchers.IO) { RadioBrowser.fetch(cc, st) }
                val merged = LinkedHashMap<String, Station>()
                all.filter { it.source == Source.ONLINE }.forEach { merged[it.id] = it }
                got.forEach { merged[it.id] = it }
                withContext(Dispatchers.IO) { StationStore.saveOnline(ctx, merged.values.toList()) }
                all = all.filter { it.source != Source.ONLINE } + merged.values
                if (country.isBlank()) chooseCountry(cc.trim().uppercase())
                message = if (got.isEmpty()) "No stations found for that place" else "Saved ${got.size} stations. They work offline now."
            } catch (e: Exception) {
                message = "Could not download: ${e.message ?: "check your internet"}"
            }
        }
    }

    /** Returns an error text, or null when the station was added. */
    fun addCommunity(name: String, freqText: String, place: String, url: String): String? {
        if (name.isBlank()) return "Enter a name"
        val f = freqText.trim().replace(',', '.').toDoubleOrNull() ?: 0.0
        if (freqText.isNotBlank() && (f < 76.0 || f > 108.0)) return "Frequency must be between 76 and 108 MHz"
        val u = url.trim()
        if (u.isNotEmpty() && !(u.startsWith("http://") || u.startsWith("https://"))) return "Stream address must start with http:// or https://"
        if (f == 0.0 && u.isEmpty()) return "Add a frequency, a stream address, or both"
        val cc = country.ifBlank { AppConfig.defaultCountry }
        val s = Station(
            id = "c-" + System.currentTimeMillis(), name = name.trim().take(60), freqMhz = f,
            country = countries().firstOrNull { it.first == cc }?.second ?: "", countryCode = cc,
            state = place.trim().take(40), streamUrl = u, source = Source.COMMUNITY,
        )
        all = all + s
        saveCommunity()
        return null
    }

    fun deleteCommunity(id: String) {
        all = all.filter { it.id != id }
        favorites = favorites - id
        prefs.edit().putStringSet("fav", favorites).apply()
        saveCommunity()
    }

    private fun saveCommunity() {
        val list = all.filter { it.source == Source.COMMUNITY }
        viewModelScope.launch(Dispatchers.IO) { StationStore.saveCommunity(ctx, list) }
    }

    // ---------- internet streams ----------

    fun play(s: Station) {
        if (!s.canStream || !AppConfig.has("streams")) {
            if (s.freqMhz > 0 && AppConfig.has("dongle")) {
                fmFreq = s.freqMhz
                Toast.makeText(ctx, "No internet stream for this station. Open FM Tuner to hear ${s.freqLabel} with a USB dongle.", Toast.LENGTH_LONG).show()
            } else Toast.makeText(ctx, "This station has no stream", Toast.LENGTH_SHORT).show()
            return
        }
        stopDongle()
        val c = controller ?: run { message = "The radio player is still starting"; return }
        current = s
        hasError = false; failed = false; retries = 0; rebuffers.clear(); nowTitle = ""
        val item = MediaItem.Builder()
            .setMediaId(s.id)
            .setUri(s.streamUrl)
            .setMediaMetadata(
                MediaMetadata.Builder().setTitle(s.name)
                    .setArtist(listOf(s.freqLabel, s.state).filter { it.isNotBlank() }.joinToString(" · ")).build()
            ).build()
        c.setMediaItem(item)
        c.prepare()
        c.play()
    }

    fun togglePlay() {
        val fm = FmEngine.state.value
        if (fm.running || fm.connecting) { stopDongle(); return }
        val c = controller ?: return
        if (c.isPlaying || (c.playWhenReady && c.playbackState == Player.STATE_BUFFERING)) c.pause()
        else current?.let { play(it) } // reconnect to the live edge instead of resuming old audio
    }

    private fun scheduleRetry() {
        if (retries >= 6) { failed = true; return }
        retries++
        val wait = 1500L * retries
        viewModelScope.launch {
            delay(wait)
            val c = controller
            if (c != null && current != null && hasError && !failed) { c.prepare(); c.play() }
        }
    }

    private fun online(): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return false
        val n = cm.activeNetwork ?: return false
        return cm.getNetworkCapabilities(n)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    }

    private fun refresh() {
        val c = controller
        val fm = FmEngine.state.value
        playing = (c?.isPlaying == true) || fm.running
        status = when {
            fm.running -> "FM tuner"
            fm.connecting -> "Connecting to dongle..."
            c == null || current == null -> ""
            !online() -> "No internet"
            failed -> "Station not responding. Try another."
            hasError -> "Reconnecting..."
            c.playbackState == Player.STATE_BUFFERING && c.playWhenReady -> "Buffering..."
            c.isPlaying -> "Live"
            else -> "Paused"
        }
        updateQuality()
    }

    private fun updateQuality() {
        val c = controller
        val active = c != null && (c.isPlaying || (c.playWhenReady && c.playbackState == Player.STATE_BUFFERING))
        quality = when {
            !active || !online() -> 0
            hasError -> 1
            else -> when (rebuffers.size) { 0 -> 4; 1 -> 3; 2 -> 2; else -> 1 }
        }
    }

    // ---------- USB dongle ----------

    fun setFm(mhz: Double) {
        fmFreq = mhz
        prefs.edit().putFloat("fm", mhz.toFloat()).apply()
        if (FmEngine.state.value.running) FmEngine.tune(mhz)
    }

    fun startDongle() {
        controller?.pause()
        dongleActive = true
        FmEngine.start(fmFreq)
        DongleService.start(ctx, "FM ${fmtMhz(fmFreq)} MHz")
    }

    fun stopDongle() {
        FmEngine.stop()
        if (dongleActive) { dongleActive = false; DongleService.stop(ctx) }
        refresh()
    }

    // ---------- sleep timer ----------

    fun setSleep(minutes: Int) {
        sleepEnd = if (minutes <= 0) 0L else System.currentTimeMillis() + minutes * 60_000L
        sleepLeftSec = if (minutes <= 0) 0 else minutes * 60
    }

    private fun tick() {
        val now = System.currentTimeMillis()
        if (sleepEnd > 0) {
            val left = ((sleepEnd - now) / 1000).toInt()
            if (left <= 0) {
                sleepEnd = 0; sleepLeftSec = 0
                controller?.pause(); stopDongle()
                message = "Sleep timer: radio stopped"
            } else sleepLeftSec = left
        }
        while (rebuffers.isNotEmpty() && now - rebuffers.first() > 60_000) rebuffers.removeFirst()
        refresh()
    }

    override fun onCleared() {
        controller?.release()
        super.onCleared()
    }
}
