package com.radiopro

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

enum class Source { BUNDLED, ONLINE, COMMUNITY }

fun fmtMhz(x: Double): String = String.format(Locale.US, "%.1f", x)

/** One radio station. freqMhz is 0 when the frequency is not known. streamUrl is empty for FM-only stations. */
data class Station(
    val id: String,
    val name: String,
    val freqMhz: Double = 0.0,
    val country: String = "",
    val countryCode: String = "",
    val state: String = "",
    val streamUrl: String = "",
    val homepage: String = "",
    val tags: String = "",
    val bitrate: Int = 0,
    val source: Source = Source.ONLINE,
) {
    val freqLabel: String get() = if (freqMhz > 0) fmtMhz(freqMhz) + " FM" else ""
    val canStream: Boolean get() = streamUrl.isNotBlank()
}

object StationJson {
    fun toJson(s: Station): JSONObject = JSONObject()
        .put("id", s.id).put("name", s.name).put("freq", s.freqMhz).put("cc", s.countryCode)
        .put("country", s.country).put("state", s.state).put("url", s.streamUrl)
        .put("home", s.homepage).put("tags", s.tags).put("kbps", s.bitrate)

    fun fromJson(j: JSONObject, src: Source): Station {
        val name = j.getString("name")
        val freq = j.optDouble("freq", 0.0)
        return Station(
            id = j.optString("id").ifBlank { "${src.name}-$name-$freq" },
            name = name, freqMhz = if (freq.isNaN()) 0.0 else freq,
            countryCode = j.optString("cc"), country = j.optString("country"), state = j.optString("state"),
            streamUrl = j.optString("url"), homepage = j.optString("home"), tags = j.optString("tags"),
            bitrate = j.optInt("kbps", 0), source = src,
        )
    }

    fun list(text: String, src: Source): List<Station> {
        val a = JSONArray(text)
        val out = ArrayList<Station>()
        for (i in 0 until a.length()) {
            try { out += fromJson(a.getJSONObject(i), src) } catch (e: Exception) { /* skip a bad row */ }
        }
        return out
    }
}

/** Lists live on the phone, so browsing works with no internet. */
object StationStore {
    private const val ONLINE = "stations_online.json"
    private const val COMMUNITY = "stations_community.json"

    fun loadAll(ctx: Context): List<Station> {
        val out = ArrayList<Station>()
        try { out += StationJson.list(ctx.assets.open("stations.json").bufferedReader().use { it.readText() }, Source.BUNDLED) } catch (e: Exception) { }
        for ((fn, src) in listOf(ONLINE to Source.ONLINE, COMMUNITY to Source.COMMUNITY)) {
            val f = File(ctx.filesDir, fn)
            if (f.exists()) try { out += StationJson.list(f.readText(), src) } catch (e: Exception) { }
        }
        return out
    }

    private fun save(ctx: Context, fn: String, list: List<Station>) {
        val a = JSONArray()
        list.forEach { a.put(StationJson.toJson(it)) }
        val tmp = File(ctx.filesDir, "$fn.tmp")
        tmp.writeText(a.toString())
        tmp.renameTo(File(ctx.filesDir, fn))
    }

    fun saveOnline(ctx: Context, list: List<Station>) = save(ctx, ONLINE, list)
    fun saveCommunity(ctx: Context, list: List<Station>) = save(ctx, COMMUNITY, list)
}

/** Free, open station directory (radio-browser.info). Used only when the person taps "Download stations". */
object RadioBrowser {
    private val hosts = listOf("de1.api.radio-browser.info", "nl1.api.radio-browser.info", "at1.api.radio-browser.info")
    private val freqRegex = Regex("""(?<![\d.])(8[7-9]|9\d|10[0-8])[.,](\d{1,2})(?!\d)""")

    /** Many stations carry their frequency in the name, for example "Cool FM 96.9". */
    fun freqFromName(name: String): Double {
        val m = freqRegex.find(name) ?: return 0.0
        return "${m.groupValues[1]}.${m.groupValues[2]}".toDoubleOrNull() ?: 0.0
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    fun fetch(countryCode: String, state: String, limit: Int = 500): List<Station> {
        var last: Exception? = null
        for (h in hosts) {
            try {
                val q = StringBuilder("https://$h/json/stations/search?hidebroken=true&order=clickcount&reverse=true&limit=$limit")
                q.append("&countrycode=").append(enc(countryCode.trim().uppercase()))
                if (state.isNotBlank()) q.append("&state=").append(enc(state.trim()))
                val con = URL(q.toString()).openConnection() as HttpURLConnection
                con.connectTimeout = 8000
                con.readTimeout = 20000
                con.setRequestProperty("User-Agent", "RadioPro/1.0")
                if (con.responseCode != 200) throw IOException("Server said ${con.responseCode}")
                val text = con.inputStream.bufferedReader().use { it.readText() }
                return parse(text)
            } catch (e: Exception) { last = e }
        }
        throw last ?: IOException("No server answered")
    }

    private fun parse(text: String): List<Station> {
        val a = JSONArray(text)
        val out = ArrayList<Station>()
        for (i in 0 until a.length()) {
            val j = a.getJSONObject(i)
            val url = j.optString("url_resolved").ifBlank { j.optString("url") }.trim()
            val name = j.optString("name").trim()
            if (url.isEmpty() || name.isEmpty()) continue
            if (!(url.startsWith("http://") || url.startsWith("https://"))) continue
            out += Station(
                id = "rb-" + j.optString("stationuuid"), name = name, freqMhz = freqFromName(name),
                country = j.optString("country"), countryCode = j.optString("countrycode").uppercase(),
                state = j.optString("state").trim(), streamUrl = url, homepage = j.optString("homepage"),
                tags = j.optString("tags"), bitrate = j.optInt("bitrate", 0), source = Source.ONLINE,
            )
        }
        return out
    }
}
