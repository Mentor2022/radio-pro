package com.radiopro

import android.content.Context
import org.json.JSONObject

/**
 * Settings chosen by the admin in the portal. The build writes them to assets/config.json.
 * Without that file (a plain build), everything is on and the default country is Nigeria.
 */
object AppConfig {
    private val allFeatures = setOf("streams", "dongle", "community", "import", "sleep", "tv", "music", "recordings", "podcasts", "timers", "equalizer")

    @Volatile var features: Set<String> = allFeatures
    /** Two-letter country code the station list opens on (NG, GH, KE ...). */
    @Volatile var defaultCountry: String = "NG"
    /** Optional state the station list opens on, for example "Lagos". */
    @Volatile var defaultState: String = ""

    /** Where live TV channel lists come from. {cc} becomes the country code. */
    @Volatile var tvPlaylist: String = "https://iptv-org.github.io/iptv/countries/{cc}.m3u"

    @Volatile var adsOn: Boolean = false
    /** Banner ad unit. Empty means Google's test banner. */
    @Volatile var bannerId: String = "ca-app-pub-3940256099942544/6300978111"

    fun has(feature: String): Boolean = feature in features

    fun load(ctx: Context) {
        try {
            val j = JSONObject(ctx.assets.open("config.json").bufferedReader().use { it.readText() })
            val f = j.optJSONObject("features")
            if (f != null) features = allFeatures.filter { f.optBoolean(it, true) }.toSet()
            defaultCountry = j.optString("country", "NG").uppercase().take(2)
            defaultState = j.optString("state", "").take(40)
            val ads = j.optJSONObject("ads")
            if (ads != null) {
                adsOn = ads.optBoolean("on", false)
                val b = ads.optString("bannerId", "")
                if (Regex("^ca-app-pub-[0-9]{16}/[0-9]{10}$").matches(b)) bannerId = b
            }
            val tp = j.optString("tvPlaylist", "")
            if (tp.startsWith("https://") && tp.length < 300) tvPlaylist = tp
        } catch (e: Exception) {
            // no config: keep the defaults
        }
    }
}
