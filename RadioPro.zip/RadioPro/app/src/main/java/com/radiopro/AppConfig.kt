package com.radiopro

import android.content.Context
import org.json.JSONObject

/**
 * Settings chosen by the admin in the portal. The build writes them to assets/config.json.
 * Without that file (a plain build), everything is on and the default country is Nigeria.
 */
object AppConfig {
    private val allFeatures = setOf("streams", "dongle", "community", "import", "sleep")

    @Volatile var features: Set<String> = allFeatures
    /** Two-letter country code the station list opens on (NG, GH, KE ...). */
    @Volatile var defaultCountry: String = "NG"
    /** Optional state the station list opens on, for example "Lagos". */
    @Volatile var defaultState: String = ""

    fun has(feature: String): Boolean = feature in features

    fun load(ctx: Context) {
        try {
            val j = JSONObject(ctx.assets.open("config.json").bufferedReader().use { it.readText() })
            val f = j.optJSONObject("features")
            if (f != null) features = allFeatures.filter { f.optBoolean(it, true) }.toSet()
            defaultCountry = j.optString("country", "NG").uppercase().take(2)
            defaultState = j.optString("state", "").take(40)
        } catch (e: Exception) {
            // no config: keep the defaults
        }
    }
}
