package com.radiopro

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

/** A station found by the scan. */
data class Found(val mhz: Double, val clarityPct: Int)

data class FmState(
    val running: Boolean = false,
    val connecting: Boolean = false,
    val freqMhz: Double = 99.3,
    val strengthPct: Int = 0,
    val clarityPct: Int = 0,
    val bars: Int = 0,
    val scanning: Boolean = false,
    val scanPct: Int = 0,
    val found: List<Found> = emptyList(),
    val message: String = "",
)

/**
 * Real FM radio from an RTL-SDR USB dongle, with no internet.
 *
 * The free "RTL-SDR driver" app (marto.rtl_tcp_andro) owns the USB dongle and serves raw radio samples on
 * 127.0.0.1:1234 (the rtl_tcp protocol). This engine reads those samples, tunes, filters, demodulates the FM
 * signal and plays it. All of the maths is plain Kotlin, so no native code is needed.
 *
 * Signal chain: 960 kHz IQ -> low-pass 100 kHz, /4 -> 240 kHz -> FM demodulator -> low-pass 15 kHz, /5 ->
 * 48 kHz mono audio -> 50 microsecond de-emphasis -> AudioTrack.
 */
object FmEngine {
    const val SAMPLE_RATE = 960_000
    private const val AUDIO_RATE = 48_000
    private const val PORT = 1234

    val state = MutableStateFlow(FmState())

    private class Run {
        @Volatile var alive = true
        @Volatile var socket: Socket? = null
        @Volatile var out: OutputStream? = null
    }

    private val lock = Any()
    private var cur: Run? = null
    @Volatile private var scanRequested = false
    @Volatile private var gainTenths = 402     // 40.2 dB, a good middle for FM
    @Volatile private var volume = 1.0f

    // ---------- control (called from the screen) ----------

    fun start(freqMhz: Double) {
        val run = synchronized(lock) { if (cur != null) null else Run().also { cur = it } }
        if (run == null) { tune(freqMhz); return }
        state.value = FmState(connecting = true, freqMhz = freqMhz, message = "Connecting to the USB driver...")
        Thread({ runLoop(run, freqMhz) }, "fm-engine").start()
    }

    fun stop() {
        val r = synchronized(lock) { val x = cur; cur = null; x }
        r?.alive = false
        try { r?.socket?.close() } catch (e: Exception) { }
        state.update { it.copy(running = false, connecting = false, scanning = false, strengthPct = 0, clarityPct = 0, bars = 0, message = "") }
    }

    fun tune(mhz: Double) {
        state.update { it.copy(freqMhz = mhz) }
        send(cur, 0x01, (mhz * 1e6).roundToInt())
    }

    fun setGainDb(db: Float) {
        gainTenths = (db * 10).roundToInt()
        send(cur, 0x04, gainTenths)
    }

    fun setVolume(v: Float) { volume = v.coerceIn(0f, 1f) }

    fun scan() {
        if (state.value.running && !state.value.scanning) scanRequested = true
    }

    /** rtl_tcp command: one byte, then a 32-bit big-endian number. */
    private fun send(run: Run?, cmd: Int, value: Int) {
        val o = run?.out ?: return
        try {
            synchronized(o) {
                o.write(byteArrayOf(cmd.toByte(), (value ushr 24).toByte(), (value ushr 16).toByte(), (value ushr 8).toByte(), value.toByte()))
                o.flush()
            }
        } catch (e: Exception) { /* the read loop notices a broken connection */ }
    }

    // ---------- the radio itself ----------

    private class Scan(val restore: Double) {
        val first = 875          // 87.5 MHz in tenths
        val last = 1080          // 108.0 MHz
        var idx = first
        var settle = 2
        var n = 0
        var acc = 0.0
        val clarity = DoubleArray(last - first + 1)
        val mhz: Double get() = idx / 10.0
    }

    private fun runLoop(run: Run, startMhz: Double) {
        var track: AudioTrack? = null
        try {
            // the driver app needs a moment to start its server
            var socket: Socket? = null
            for (i in 0 until 14) {
                if (!run.alive) return
                try {
                    socket = Socket().also { it.connect(InetSocketAddress("127.0.0.1", PORT), 1500) }
                    break
                } catch (e: Exception) { Thread.sleep(500) }
            }
            if (socket == null) {
                state.update { it.copy(connecting = false, running = false, message = "Could not reach the USB driver. Plug in the dongle and allow the RTL-SDR driver app to use it.") }
                return
            }
            run.socket = socket
            socket.soTimeout = 6000
            socket.tcpNoDelay = true
            val inp = DataInputStream(BufferedInputStream(socket.getInputStream(), 1 shl 16))
            run.out = socket.getOutputStream()
            try { inp.readFully(ByteArray(12)) } catch (e: Exception) { /* "RTL0" header: not needed */ }

            send(run, 0x02, SAMPLE_RATE)
            send(run, 0x03, 1)                 // manual gain, so signal readings are comparable
            send(run, 0x04, gainTenths)
            send(run, 0x05, 0)                 // frequency correction: none
            send(run, 0x01, (startMhz * 1e6).roundToInt())

            val minBuf = AudioTrack.getMinBufferSize(AUDIO_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(AUDIO_RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(max(minBuf * 2, AUDIO_RATE))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track.play()
            state.update { it.copy(connecting = false, running = true, message = "Listening") }

            val raw = ByteArray(65536)
            val n = raw.size / 2
            val iBuf = FloatArray(n); val qBuf = FloatArray(n)
            val iD = FloatArray(n / 4 + 8); val qD = FloatArray(n / 4 + 8)
            val dem = FloatArray(n / 4 + 8)
            val aud = FloatArray(n / 20 + 8)
            val pcm = ShortArray(n / 20 + 8)
            val f1I = FirDecim(lowpass(41, 100_000.0, SAMPLE_RATE.toDouble()), 4)
            val f1Q = FirDecim(lowpass(41, 100_000.0, SAMPLE_RATE.toDouble()), 4)
            val f2 = FirDecim(lowpass(63, 15_000.0, 240_000.0), 5)
            val deAlpha = (1.0 - exp(-1.0 / (AUDIO_RATE * 50e-6))).toFloat()   // 50 us de-emphasis (Africa, Europe)
            var pI = 0f; var pQ = 0f; var y = 0f
            var clarSmooth = 0.0; var strSmooth = 0.0
            var blocks = 0
            var scan: Scan? = null

            while (run.alive) {
                inp.readFully(raw)
                var pw = 0.0
                for (k in 0 until n) {
                    val i = ((raw[2 * k].toInt() and 0xFF) - 127.5f) / 127.5f
                    val q = ((raw[2 * k + 1].toInt() and 0xFF) - 127.5f) / 127.5f
                    iBuf[k] = i; qBuf[k] = q
                    pw += i * i + q * q
                }
                val pAll = pw / n
                val m = f1I.process(iBuf, n, iD)
                f1Q.process(qBuf, n, qD)
                var pc = 0.0
                for (k in 0 until m) pc += iD[k] * iD[k] + qD[k] * qD[k]
                val pChan = if (m > 0) pc / m else 0.0

                // Clarity: how much of the received power sits inside the tuned 200 kHz channel.
                // Pure noise gives about 0.21, a strong station gives much more.
                val ratio = pChan / max(pAll, 1e-9)
                val clarity = ((ratio - 0.25) / 0.55).coerceIn(0.0, 1.0)
                val strength = ((10 * log10(max(pChan, 1e-9)) + 45.0) / 35.0).coerceIn(0.0, 1.0)

                // ----- scan: step through the FM band and measure each channel -----
                if (scanRequested) {
                    scanRequested = false
                    scan = Scan(state.value.freqMhz).also { tune(it.mhz) }
                    state.update { it.copy(scanning = true, scanPct = 0, found = emptyList(), message = "Scanning the FM band...") }
                }
                val sc = scan
                if (sc != null) {
                    if (sc.settle > 0) sc.settle-- else {
                        sc.acc += clarity; sc.n++
                        if (sc.n >= 3) {
                            sc.clarity[sc.idx - sc.first] = sc.acc / sc.n
                            sc.idx++
                            if (sc.idx > sc.last) {
                                val found = peaks(sc)
                                scan = null
                                tune(sc.restore)
                                state.update { it.copy(scanning = false, scanPct = 100, found = found, message = if (found.isEmpty()) "No stations found. Check the antenna." else "Found ${found.size} stations") }
                            } else {
                                tune(sc.mhz); sc.settle = 2; sc.n = 0; sc.acc = 0.0
                                state.update { it.copy(scanPct = (sc.idx - sc.first) * 100 / (sc.last - sc.first)) }
                            }
                        }
                    }
                }

                // ----- FM demodulation -----
                for (k in 0 until m) {
                    val i = iD[k]; val q = qD[k]
                    val re = i * pI + q * pQ
                    val im = q * pI - i * pQ
                    pI = i; pQ = q
                    dem[k] = (atan2(im.toDouble(), re.toDouble()) * 0.5).toFloat()
                }
                val a = f2.process(dem, m, aud)
                for (k in 0 until a) {
                    y += deAlpha * (aud[k] - y)
                    pcm[k] = (y * volume * 28000f).toInt().coerceIn(-32768, 32767).toShort()
                }
                if (scan == null) track.write(pcm, 0, a)

                // ----- meters, about 5 times a second -----
                clarSmooth += 0.3 * (clarity - clarSmooth)
                strSmooth += 0.3 * (strength - strSmooth)
                if (++blocks % 3 == 0 && scan == null) {
                    val c = clarSmooth
                    val bars = when { c >= 0.8 -> 4; c >= 0.55 -> 3; c >= 0.3 -> 2; c >= 0.12 -> 1; else -> 0 }
                    state.update { it.copy(strengthPct = (strSmooth * 100).toInt(), clarityPct = (c * 100).toInt(), bars = bars) }
                }
            }
        } catch (e: Exception) {
            if (run.alive) state.update { it.copy(running = false, connecting = false, scanning = false, message = "Lost the USB driver. Check the dongle and start again.") }
        } finally {
            try { track?.stop() } catch (e: Exception) { }
            try { track?.release() } catch (e: Exception) { }
            try { run.socket?.close() } catch (e: Exception) { }
            synchronized(lock) { if (cur === run) cur = null }
            if (cur == null) state.update { it.copy(running = false, connecting = false) }
        }
    }

    /** Local maxima of clarity, at least 0.2 MHz apart, strong enough to be a real station. */
    private fun peaks(sc: Scan): List<Found> {
        val c = sc.clarity
        val out = ArrayList<Found>()
        for (i in c.indices) {
            if (c[i] < 0.40) continue
            var isMax = true
            for (d in -2..2) {
                val j = i + d
                if (d != 0 && j in c.indices && c[j] > c[i]) { isMax = false; break }
            }
            if (isMax) out += Found((sc.first + i) / 10.0, (c[i] * 100).toInt())
        }
        return out
    }

    // ---------- small filters ----------

    /** Low-pass FIR that also drops samples (decimates), so it only computes the outputs it keeps. */
    private class FirDecim(private val taps: FloatArray, private val m: Int) {
        private val nt = taps.size
        private val hist = FloatArray(nt - 1)
        private var tmp = FloatArray(0)
        private var phase = 0

        fun process(inp: FloatArray, n: Int, out: FloatArray): Int {
            val total = nt - 1 + n
            if (tmp.size < total) tmp = FloatArray(total)
            System.arraycopy(hist, 0, tmp, 0, nt - 1)
            System.arraycopy(inp, 0, tmp, nt - 1, n)
            var o = 0
            var i = phase
            while (i + nt <= total) {
                var acc = 0f
                for (k in 0 until nt) acc += tmp[i + k] * taps[k]
                out[o++] = acc
                i += m
            }
            phase = i - n
            System.arraycopy(tmp, total - (nt - 1), hist, 0, nt - 1)
            return o
        }
    }

    /** Windowed-sinc low-pass filter taps with unity gain at 0 Hz. */
    private fun lowpass(n: Int, cutoffHz: Double, fs: Double): FloatArray {
        val fc = cutoffHz / fs
        val h = DoubleArray(n)
        val mid = (n - 1) / 2.0
        var sum = 0.0
        for (k in 0 until n) {
            val x = k - mid
            val s = if (abs(x) < 1e-9) 2 * fc else sin(2 * PI * fc * x) / (PI * x)
            h[k] = s * (0.54 - 0.46 * cos(2 * PI * k / (n - 1)))
            sum += h[k]
        }
        return FloatArray(n) { (h[it] / sum).toFloat() }
    }
}
