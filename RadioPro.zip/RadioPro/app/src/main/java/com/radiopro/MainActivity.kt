package com.radiopro

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppConfig.load(this) // before the view model reads the default country
        if (AppConfig.adsOn) com.google.android.gms.ads.MobileAds.initialize(this) {}
        setContent {
            RadioProTheme {
                val vm: RadioViewModel = viewModel()
                RadioApp(vm)
            }
        }
    }
}

@Composable
fun RadioApp(vm: RadioViewModel) {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableStateOf(0) }

    val askNotifications = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    val tabs = buildList {
        add("Stations" to "📻")
        add("Favorites" to "♥")
        if (AppConfig.has("music")) add("Music" to "🎵")
        if (AppConfig.has("tv")) add("TV" to "📺")
        if (AppConfig.has("dongle")) add("FM Tuner" to "📡")
        add("More" to "⚙")
    }
    val index = tab.coerceIn(0, tabs.size - 1)

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            Column {
                MiniPlayer(vm)
                NavigationBar {
                    tabs.forEachIndexed { i, t ->
                        NavigationBarItem(selected = index == i, onClick = { tab = i }, icon = { Text(t.second) }, label = { Text(t.first, fontSize = 10.sp, maxLines = 1, softWrap = false) }, alwaysShowLabel = true)
                    }
                }
            }
        },
    ) { pad ->
        Column(Modifier.padding(pad)) {
            if (AppConfig.adsOn) AdBanner()
            Box(Modifier.weight(1f)) {
                when (tabs[index].first) {
                    "Stations" -> StationsScreen(vm, favOnly = false)
                    "Favorites" -> StationsScreen(vm, favOnly = true)
                    "Music" -> MusicScreen(vm)
                    "TV" -> TvScreen(vm)
                    "FM Tuner" -> TunerScreen(vm)
                    else -> MoreScreen(vm)
                }
            }
        }
    }
}

/** A small Google AdMob banner. It only exists when the admin turned ads on in the portal. */
@Composable
fun AdBanner() {
    androidx.compose.ui.viewinterop.AndroidView(
        factory = { c ->
            com.google.android.gms.ads.AdView(c).apply {
                setAdSize(com.google.android.gms.ads.AdSize.BANNER)
                adUnitId = AppConfig.bannerId
                loadAd(com.google.android.gms.ads.AdRequest.Builder().build())
            }
        },
        modifier = Modifier.fillMaxWidth(),
    )
}
