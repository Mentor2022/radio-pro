# Radio Pro
Radio for Android (Jetpack Compose + Media3). Same project shape as Video Pro, so it can be built by GitHub Actions and managed from the App Builder Portal.

## What it does
- **Stations**: browse by country, state and community, sorted by frequency, with search ("99.3"). The list is stored on the phone, so browsing, favourites and community stations work with no internet.
- **Internet streams**: background playback with notification and lock-screen controls, auto-reconnect (6 tries), live "now playing" text when the station sends it, sleep timer. The signal bars show stream quality (how often it had to stop and refill in the last minute).
- **FM Tuner (add-on)**: real FM radio from an RTL-SDR USB dongle, no internet. Tune 87.5 to 108.0 MHz, signal strength and clarity meters, gain control, and a band scan that lists the stations really on air where you are. Found stations can be saved as community stations.
- **Download stations** (More tab): one tap saves a country or state from the open radio-browser.info directory. Frequencies are read from station names when they contain one (for example "Cool FM 96.9").
- **Community stations**: add a local or campus station by frequency, stream address or both.

## Layout
| File | Job |
|---|---|
| `Stations.kt` | Station model, offline storage, radio-browser.info importer |
| `RadioViewModel.kt` | Filters, favourites, playback control, retries, stream quality, sleep timer, dongle control |
| `PlaybackService.kt` | Media3 background player for streams |
| `FmEngine.kt` | rtl_tcp client + FM demodulator + band scan (pure Kotlin) |
| `DongleService.kt` | Foreground service so the dongle radio keeps playing with the screen off |
| `Screens.kt`, `MainActivity.kt`, `Theme.kt` | UI |
| `AppConfig.kt` | Portal settings from `assets/config.json` |

## Dongle mode, how it connects
The free **RTL-SDR driver** app (`marto.rtl_tcp_andro`) owns the USB dongle and serves samples on `127.0.0.1:1234`. Radio Pro starts it with an `iqsrc://` link, reads the samples, and decodes the FM audio itself. Needs a phone with USB OTG, an RTL-SDR dongle (RTL-SDR Blog, NESDR) and an antenna. Mono audio, 50 microsecond de-emphasis; stereo and RDS station names are not decoded yet.

## assets/config.json (written by the build, optional)
```json
{ "features": {"streams": true, "dongle": true, "community": true, "import": true, "sleep": true},
  "country": "NG", "state": "Lagos" }
```
Without this file everything is on and the list opens on Nigeria.

## Build with GitHub (how your portal does it)
Put this folder at the root of the repo `<github_owner>/radio-pro`, add the four signing secrets (see the top of `.github/workflows/radio-release.yml`), then press Build in the portal's Radio Pro page.

## Build on your own computer
Needs JDK 17, Android SDK 35 and Gradle 8.11+: `gradle :app:assembleRelease`. Environment variables are the same as Video Pro: `APP_NAME`, `VERSION_CODE`, `KEYSTORE_PATH`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.

## Check before you ship
- `assets/stations.json` is a tiny starter list (frequencies only, no streams). Confirm each frequency before release; real streams come from Download stations.
- Dongle mode and the clarity maths were written without a dongle to test. Try it on a real phone and dongle, then tune the thresholds in `FmEngine.kt`.
- Many radio streams are plain http, so cleartext traffic is allowed in the manifest.
- Stream URLs come from a community directory. Some will be dead or change; the app retries and shows "Station not responding".
